from consolesize import ConsoleSize

__all__ = ['ConsoleSize']
