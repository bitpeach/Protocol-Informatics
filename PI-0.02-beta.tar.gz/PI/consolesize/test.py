#!/usr/bin/env python

from consolesize import ConsoleSize

if __name__ == '__main__':
    print 'size   :', ConsoleSize.size
    print 'width  :', ConsoleSize.width
    print 'height :', ConsoleSize.height
